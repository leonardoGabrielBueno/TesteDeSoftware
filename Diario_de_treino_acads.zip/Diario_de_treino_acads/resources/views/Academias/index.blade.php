@extends('app')


@section('content')
    <div class="container">
        <h1>Academias</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Nome</th>
                <th>CNPJ</th>
				<th>Dono</th>
                <th>Ação</th>
            </tr>
            </thead>

            <tbody>
            @foreach($academias as $acads)
                <tr>
                    <td>{{ $acads->nome }}</td>
                    <td>{{ $acads->cnpj }}</td>
					<td>{{ $acads->dono->nome }}</td>
                    <td>
                        <a href="{{ route('academias.edit', ['id'=>$acads->id]) }}"
                           class="btn-sm btn-success">Editar</a>
                        <a href="{{ route('academias.destroy', ['id'=>$acads->id]) }}"
                           class="btn-sm btn-danger">Remover</a>
                    </td>

                </tr>
            @endforeach
            </tbody>
        </table>
		<a href="academias/create" class="btn btn-primary">Novo</a>
		<a href="donos" class="btn btn-primary">Donos</a>
		<a href="exercicios" class="btn btn-primary">Exercicios</a>
		<a href="treinos" class="btn btn-primary">Treinos</a>


    </div>
@endsection