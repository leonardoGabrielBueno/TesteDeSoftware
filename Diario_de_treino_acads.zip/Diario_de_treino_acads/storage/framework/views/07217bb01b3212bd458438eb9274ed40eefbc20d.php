<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Exercicios</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Tipo</th>
                <th>Ação</th>
            </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $exercicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e($exe->nome); ?></td>
                       <td><?php echo e($exe->descricao); ?></td>

                       <?php if($exe->tp_exercicio == 'B'): ?>
                           <td>Braços</td>
                       <?php elseif($exe->tp_exercicio == 'P'): ?>
                           <td>Ruim</td>
                       <?php endif; ?>

                       <td>
                           <a href="<?php echo e(route('exercicios.edit', ['id'=>$exe->id])); ?>"
                                        class="btn-sm btn-success">Editar</a>
                           <a href="<?php echo e(route('exercicios.destroy', ['id'=>$exe->id])); ?>"
                              class="btn-sm btn-danger">Remover</a>
                       </td>

                   </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
		<a href="exercicios/create" class="btn btn-primary">Novo</a>
		<a href="academias" class="btn btn-primary">Academias</a>
		<a href="donos" class="btn btn-primary">Donos</a>
		<a href="treinos" class="btn btn-primary">Treinos</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>