<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Treino extends Model
{
      protected $fillable = [
        'nome',
        'repeticoes',
		'series',
        'exercicio_id'
    ];

    public function exercicios() {
        return $this->belongsTo('App\Exercicio');
    }
}
