@extends('app')

@section('content')
    <div class="container">
        <h1>Novo Dono</h1>

        @if($errors->any())
            <ul class="alert alert-danger">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}}</li>
                @endforeach
            </ul>
        @endif

        {!! Form::open(['route' => 'donos.store']) !!}
        <div class="form-group">
            {!! Form::label('nome', 'Nome:') !!}
            {!! Form::text('nome', null,['class' =>'form-control']) !!}
        </div>

        <div class="form-group">
            {!! Form::label('idade', 'Idade:') !!}
            {!! Form::text('idade', null,['class' =>'form-control']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('sexo', 'Sexo:') !!}
            {!! Form::select('sexo',
                        array('M' => 'Masculino', 'F' => 'Feminino'),
                         'B',
                         ['class'=>'form-control']) !!}
        </div>
        
        <div class="form-group">
            {!! Form::submit('Criar Dono', ['class' =>'btn btn-primary']) !!}
			<button type="button" onclick="window.location='{{ url("donos") }}'" class="btn btn-primary">Voltar</button>
        </div>

        {!! Form::close() !!}
		
    </div>
@endsection