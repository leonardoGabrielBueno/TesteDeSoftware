<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Historicos</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Habitos</th>
                <th>Data</th>
                <th>Ação</th>
            </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $historicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
				   <tr>
                       <td><?php echo e($hist->habito->nome); ?></td>
                       <td><?php echo e($hist->data); ?></td>

                       <td>
                           <a href="<?php echo e(route('historicos.edit', ['id'=>$hist->id])); ?>"
                                        class="btn-sm btn-success">Editar</a>
                           <a href="<?php echo e(route('historicos.destroy', ['id'=>$hist->id])); ?>"
                              class="btn-sm btn-danger">Remover</a>
                       </td>

                   </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
		<a href="historicos/create" class="btn-sm btn-success">Novo</a>
		<a href="habitos" class="btn-sm btn-success">Habitos</a>
		<a href="exercicios" class="btn-sm btn-success">Exercicios</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>