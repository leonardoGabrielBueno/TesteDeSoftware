@extends('app')

@section('content')
    <div class="container">
        <h1>Novo Exercicio</h1>

        @if($errors->any())
            <ul class="alert alert-danger">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}}</li>
                @endforeach
            </ul>
        @endif

        {!! Form::open(['route' => 'exercicios.store']) !!}
        <div class="form-group">
            {!! Form::label('nome', 'Nome:') !!}
            {!! Form::text('nome', null,['class' =>'form-control']) !!}
        </div>

        <div class="form-group">
            {!! Form::label('descricao', 'Descrição:') !!}
            {!! Form::textarea('descricao', null,['class' =>'form-control']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('tp_exercicio', 'Tipo:') !!}
            {!! Form::select('tp_exercicio',
                        array('P' => 'Peito', 'P2' => 'Pernas', 'C' => 'Costas', 'B' => 'Braços'),
                         'B',
                         ['class'=>'form-control']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('objetivo', 'Objetivo:') !!}
            {!! Form::text('objetivo', null,['class' =>'form-control']) !!}
        </div>

        
        <div class="form-group">
            {!! Form::submit('Criar Exercicio', ['class' =>'btn btn-primary']) !!}
			<button type="button" onclick="window.location='{{ url("exercicios") }}'" class="btn btn-primary">Voltar</button>
        </div>

        {!! Form::close() !!}
		
    </div>
@endsection