@extends('app')


@section('content')
    <div class="container">
        <h1>Treinos</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Exercicios</th>
				<th>Musculo ALvo</th>
                <th>repetições</th>
                <th>Series</th>
				<th>Ações</th>
            </tr>
            </thead>

            <tbody>
                @foreach($treinos as $trein)
                   
				   <tr>
                       <td>{{ $trein->exercicio_id}}</td>
                       <td>{{ $trein->nome }}</td>
					   <td>{{ $trein->repeticoes }}</td>
					   <td>{{ $trein->series }}</td>

                       <td>
                           <a href="{{ route('treinos.edit', ['id'=>$trein->id]) }}"
                                        class="btn-sm btn-success">Editar</a>
                           <a href="{{ route('treinos.destroy', ['id'=>$trein->id]) }}"
                              class="btn-sm btn-danger">Remover</a>
                       </td>

                   </tr>
                @endforeach
            </tbody>
        </table>
		<a href="treinos/create" class="btn btn-primary">Novo</a>
		<a href="donos" class="btn btn-primary">Donos</a>
		<a href="exercicios" class="btn btn-primary">Exercicios</a>
		<a href="academias" class="btn btn-primary">Academias</a>
    </div>
@endsection