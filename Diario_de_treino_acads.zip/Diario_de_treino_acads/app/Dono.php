<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Dono extends Model
{
    protected $fillable = ['nome', 'idade', 'sexo'];

    public function academias(){
        return $this->hasMany('App\Academia');
    }

}
