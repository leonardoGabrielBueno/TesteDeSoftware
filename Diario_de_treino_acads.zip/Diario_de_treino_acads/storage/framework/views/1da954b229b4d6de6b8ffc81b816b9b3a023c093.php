<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Nova Academia</h1>

        <?php if($errors->any()): ?>
            <ul class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?>}</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <?php echo Form::open(['route' => 'historicos.store']); ?>

        <div class="form-group">
            <?php echo Form::label('dono_id', 'Dono:'); ?>

            <?php echo e(Form::select('dono_id',
            \App\Habito::orderBy('nome')->pluck('nome', 'id')->toArray(), null,['class' =>'form-control'])); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('nome', 'Nome:'); ?>

            <?php echo Form::text('nome', null,['class' =>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('cnpj', 'CNPJ:'); ?>

            <?php echo Form::text('cnpj', null,['class' =>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::submit('Criar Academia', ['class' =>'btn btn-primary']); ?>

        </div>

        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>