<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Hábitos</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Nome</th>
                <th>Descrição</th>
                <th>Tipo</th>
                <th>Ação</th>
            </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $habitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e($hab->nome); ?></td>
                       <td><?php echo e($hab->descricao); ?></td>

                       <?php if($hab->tp_habito == 'B'): ?>
                           <td>Bom</td>
                       <?php elseif($hab->tp_habito == 'R'): ?>
                           <td>Ruim</td>
                       <?php endif; ?>

                       <td>
                           <a href="<?php echo e(route('habitos.edit', ['id'=>$hab->id])); ?>"
                                        class="btn-sm btn-success">Editar</a>
                           <a href="<?php echo e(route('habitos.destroy', ['id'=>$hab->id])); ?>"
                              class="btn-sm btn-danger">Remover</a>
                       </td>

                   </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
		<a href="habitos/create" class="btn-sm btn-success">Novo</a>
		<a href="historicos" class="btn-sm btn-success">Historicos</a>
		<a href="exercicios" class="btn-sm btn-success">Exercicios</a>
		<a href="treinos" class="btn-sm btn-success">Treinos</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>