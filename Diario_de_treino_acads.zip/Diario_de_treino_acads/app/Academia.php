<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Academia extends Model
{
    protected $fillable = ['nome','cnpj', 'habito_id'
    ];

    public function dono() {
        return $this->belongsTo('App\Dono');
    }
}
