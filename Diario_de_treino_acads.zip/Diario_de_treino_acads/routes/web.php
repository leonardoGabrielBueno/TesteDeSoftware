<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::group(['prefix'=>'donos', 'where'=>['id'=>'[0-9]+']], function (){
    Route::get('',                      ['as'=>'donos',                   'uses'=>'DonosController@index']);
    Route::get('create',                ['as'=>'donos.create',            'uses'=>'DonosController@create']);
    Route::get('{id}/destroy',          ['as'=>'donos.destroy',           'uses'=>'DonosController@destroy']);
    Route::get('{id}/edit',             ['as'=>'donos.edit',              'uses'=>'DonosController@edit']);
    Route::put('{id}/update',           ['as'=>'donos.update',            'uses'=>'DonosController@update']);
    Route::post('store',                ['as'=>'donos.store',             'uses'=>'DonosController@store']);
});

Route::group(['prefix'=>'academias', 'where'=>['id'=>'[0-9]+']], function (){
    Route::get('',                      ['as'=>'academias',                   'uses'=>'AcademiasController@index']);
    Route::get('create',                ['as'=>'academia.create',            'uses'=>'AcademiasController@create']);
    Route::get('{id}/destroy',          ['as'=>'academias.destroy',           'uses'=>'AcademiasController@destroy']);
    Route::get('{id}/edit',             ['as'=>'academias.edit',              'uses'=>'AcademiasController@edit']);
    Route::put('{id}/update',           ['as'=>'academias.update',            'uses'=>'AcademiasController@update']);
    Route::post('store',                ['as'=>'academias.store',             'uses'=>'AcademiasController@store']);
});

Route::group(['prefix'=>'exercicios', 'where'=>['id'=>'[0-9]+']], function (){
    Route::get('',                      ['as'=>'exercicios',                   'uses'=>'ExercicioController@index']);
    Route::get('create',                ['as'=>'exercicios.create',            'uses'=>'ExercicioController@create']);
    Route::get('{id}/destroy',          ['as'=>'exercicios.destroy',           'uses'=>'ExercicioController@destroy']);
    Route::get('{id}/edit',             ['as'=>'exercicios.edit',              'uses'=>'ExercicioController@edit']);
    Route::put('{id}/update',           ['as'=>'exercicios.update',            'uses'=>'ExercicioController@update']);
    Route::post('store',                ['as'=>'exercicios.store',             'uses'=>'ExercicioController@store']);
});
Route::group(['prefix'=>'treinos', 'where'=>['id'=>'[0-9]+']], function (){
    Route::get('',                      ['as'=>'treinos',                   'uses'=>'TreinoController@index']);
    Route::get('create',                ['as'=>'treinos.create',            'uses'=>'TreinoController@create']);
    Route::get('{id}/destroy',          ['as'=>'treinos.destroy',           'uses'=>'TreinoController@destroy']);
    Route::get('{id}/edit',             ['as'=>'treinos.edit',              'uses'=>'TreinoController@edit']);
    Route::put('{id}/update',           ['as'=>'treinos.update',            'uses'=>'TreinoController@update']);
    Route::post('store',                ['as'=>'treinos.store',             'uses'=>'TreinoController@store']);
});