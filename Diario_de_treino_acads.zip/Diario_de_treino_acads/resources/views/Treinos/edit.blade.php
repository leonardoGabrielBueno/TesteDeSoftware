@extends('app')

@section('content')
    <div class="container">
        <h1>Editando Treino: {{$treino->nome}}</h1>

        @if($errors->any())
            <ul class="alert alert-danger">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}}</li>
                @endforeach
            </ul>
        @endif

		  {!! Form::open(['route' => 'treinos.update']) !!}
        <div class="form-group">
            {!! Form::label('exercicio_id', 'Exercicio:') !!}
            {{ Form::select('exercicio_id', $treino->exercicio_id->nome,
            \App\Exercicio::orderBy('nome')->pluck('nome', 'id')->toArray(), null,['class' =>'form-control']) }}
        </div>
		
		<div class="form-group">
            {!! Form::label('repeticoes', 'Repetições:') !!}
            {!! Form::text('repeticoes', $treino->repeticoes ,['class' =>'form-control']) !!}
        </div>

        <div class="form-group">
            {!! Form::label('series', 'Series:') !!}
            {!! Form::text('series', $treino->series ,['class' =>'form-control']) !!}
        </div>

       
        <div class="form-group">
            {!! Form::submit('Salvar Treino', ['class' =>'btn btn-primary']) !!}
        </div>

        {!! Form::close() !!}
    </div>
@endsection