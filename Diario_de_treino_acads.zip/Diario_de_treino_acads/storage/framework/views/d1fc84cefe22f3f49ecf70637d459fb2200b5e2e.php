<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Novo Hábito</h1>

        <?php if($errors->any()): ?>
            <ul class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?>}</li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <?php echo Form::open(['route' => 'habitos.store']); ?>

        <div class="form-group">
            <?php echo Form::label('nome', 'Nome:'); ?>

            <?php echo Form::text('nome', null,['class' =>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('descricao', 'Descrição:'); ?>

            <?php echo Form::textarea('descricao', null,['class' =>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('tp_habito', 'Tipo:'); ?>

            <?php echo Form::select('tp_habito',
                        array('B' => 'Bom', 'R' => 'Ruim'),
                         'B',
                         ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::label('objetivo', 'Objetivo:'); ?>

            <?php echo Form::number('objetivo', 1,['class' =>'form-control']); ?>

        </div>

        <div class="form-group">
            <?php echo Form::label('dt_inicio_ctrl', 'Data:'); ?>

            <?php echo Form::text('dt_inicio_ctrl',
                        '2017-05-20 00:00:00',
                         ['class'=>'form-control']); ?>

        </div>
        <div class="form-group">
            <?php echo Form::submit('Criar Hábito', ['class' =>'btn btn-primary']); ?>

			<button type="button" onclick="window.location='<?php echo e(url("habitos")); ?>'" class="btn btn-primary">Voltar</button>
        </div>

        <?php echo Form::close(); ?>

		
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>