@extends('app')

@section('content')
    <div class="container">
        <h1>Novo Treino</h1>

        @if($errors->any())
            <ul class="alert alert-danger">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}}</li>
                @endforeach
            </ul>
        @endif
		{!! Form::open(['route' => 'treinos.store']) !!}
		<div class="form-group">
            {!! Form::label('nome', 'Nome:') !!}
            {!! Form::text('nome', null ,['class' =>'form-control']) !!}
        </div>
       
		<div class="form-group">
            {!! Form::label('repeticoes', 'Repetições:') !!}
            {!! Form::text('repeticoes', null ,['class' =>'form-control']) !!}
        </div>

        <div class="form-group">
            {!! Form::label('series', 'Series:') !!}
            {!! Form::text('series', null ,['class' =>'form-control']) !!}
        </div>
        
        <div class="form-group">
            {!! Form::label('exercicio_id', 'Exercicio:') !!}
            {{ Form::select('exercicio_id', 
            \App\Exercicio::orderBy('nome')->pluck('nome', 'id')->toArray(), null,['class' =>'form-control']) }}
        </div>

        <div class="form-group">
            {!! Form::submit('Criar Treino', ['class' =>'btn btn-primary']) !!}
        </div>

        {!! Form::close() !!}
    </div>
@endsection