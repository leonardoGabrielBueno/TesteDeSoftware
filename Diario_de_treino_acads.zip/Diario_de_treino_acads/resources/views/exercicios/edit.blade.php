@extends('app')

@section('content')
    <div class="container">
        <h1>Editando Exercicio: {{$exercicio->nome}}</h1>

        @if($errors->any())
            <ul class="alert alert-danger">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}}</li>
                @endforeach
            </ul>
        @endif

        {!! Form::open(['route' => ["exercicios.update", $exercicio->id], 'method'=>'put']) !!}
        <div class="form-group">
            {!! Form::label('nome', 'Nome:') !!}
            {!! Form::text('nome', $exercicio->nome,['class' =>'form-control']) !!}
        </div>

        <div class="form-group">
            {!! Form::label('descricao', 'Descrição:') !!}
            {!! Form::textarea('descricao', $exercicio->descricao,['class' =>'form-control']) !!}
        </div>
        <div class="form-group">
            {!! Form::label('tp_exercicio', 'Tipo:') !!}
            {!! Form::select('tp_exercicio',
                        array(P' => 'Peito', 'P2' => 'Pernas', 'C' => 'Costas', 'B' => 'Braços'),
                         $exercicio->tp_exercicio,
                         ['class'=>'form-control']) !!}
        
        <div class="form-group">
            {!! Form::label('objetivo', 'Objetivo:') !!}
            {!! Form::text('objetivo', $exercicio->objetivo,['class' =>'form-control']) !!}
        </div>

        <div class="form-group">
            {!! Form::submit('Criar Exercicio', ['class' =>'btn btn-primary']) !!}
        </div>

        {!! Form::close() !!}
    </div>
@endsection