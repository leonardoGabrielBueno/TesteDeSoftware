<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Donos</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Nome</th>
                <th>Idade</th>
                <th>Sexo</th>
                <th>Ação</th>
            </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $donos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $don): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <tr>
                       <td><?php echo e($don->nome); ?></td>
                       <td><?php echo e($don->idade); ?></td>

                       <?php if($don->sexo == 'M'): ?>
                           <td>Masculino</td>
                       <?php elseif($don->sexo == 'F'): ?>
                           <td>Feminino</td>
                       <?php endif; ?>

                       <td>
                           <a href="<?php echo e(route('donos.edit', ['id'=>$don->id])); ?>"
                                        class="btn-sm btn-success">Editar</a>
                           <a href="<?php echo e(route('donos.destroy', ['id'=>$don->id])); ?>"
                              class="btn-sm btn-danger">Remover</a>
                       </td>

                   </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
		<a href="donos/create" class="btn btn-primary">Novo</a>
		<a href="academias" class="btn btn-primary">Academias</a>
		<a href="exercicios" class="btn btn-primary">Exercicios</a>
		<a href="treinos" class="btn btn-primary">Treinos</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>