<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Academia;
use App\Http\Requests\AcademiaRequest;

class AcademiasController extends Controller
{
    public function index() {
        $academias = Academia::all();
        return view('academias.index', ['academias'=>$academias]);
    }

    public function create(){
        return view ('academias.create');
    }

    public function store (AcademiaRequest $request){
        $novo_academia = $request->all();
        Academia::create($novo_academia);

        return redirect()->route('academias');
    }

    public function destroy ($id) {
        Academia::find($id)->delete();
        return redirect()->route('academias');
    }

    public function edit ($id) {
        $academia = Academia::find($id);
        return view ('academias.edit', compact('academia'));
    }

    public function update (AcademiaRequest $request, $id) {
        $academia = Academia::find($id)->update($request->all());
        return redirect()->route('academias');
    }
}
