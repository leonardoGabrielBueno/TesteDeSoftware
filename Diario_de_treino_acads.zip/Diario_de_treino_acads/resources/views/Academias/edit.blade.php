 @extends('app')

@section('content')
    <div class="container">
        <h1>Editando Academia: {{$academia->nome}}</h1>

        @if($errors->any())
            <ul class="alert alert-danger">
                @foreach($errors->all() as $error)
                    <li>{{ $error }}}</li>
                @endforeach
            </ul>
        @endif

		  {!! Form::open(['route' => 'academias.update']) !!}
        <div class="form-group">
            {!! Form::label('dono_id', 'Dono:') !!}
            {{ Form::select('dono_id', $academia->dono_id->nome,
            \App\Dono::orderBy('nome')->pluck('nome', 'id')->toArray(), null,['class' =>'form-control']) }}
        </div>
		
		<div class="form-group">
            {!! Form::label('cnpj', 'CNPJ:') !!}
            {!! Form::text('cnpj', $academia->cnpj ,['class' =>'form-control']) !!}
        </div>

        <div class="form-group">
            {!! Form::label('nome', 'Nome:') !!}
            {!! Form::text('nome', $academia->nome ,['class' =>'form-control']) !!}
        </div>
		<div class="form-group">
            {!! Form::label('idade', 'Idade:') !!}
            {!! Form::text('idade', $academia->idade ,['class' =>'form-control']) !!}
        </div>
       
        <div class="form-group">
            {!! Form::submit('Salvar academia', ['class' =>'btn btn-primary']) !!}
        </div>

        {!! Form::close() !!}
    </div>
@endsection