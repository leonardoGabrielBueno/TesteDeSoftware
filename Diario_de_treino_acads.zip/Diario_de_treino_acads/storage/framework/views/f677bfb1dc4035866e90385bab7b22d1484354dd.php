<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Academias</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Nome</th>
                <th>CNPJ</th>
				<th>Dono</th>
                <th>Ação</th>
            </tr>
            </thead>

            <tbody>
            <?php $__currentLoopData = $academias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($acads->nome); ?></td>
                    <td><?php echo e($acads->cnpj); ?></td>
					<td><?php echo e($acads->dono->nome); ?></td>
                    <td>
                        <a href="<?php echo e(route('academias.edit', ['id'=>$acads->id])); ?>"
                           class="btn-sm btn-success">Editar</a>
                        <a href="<?php echo e(route('academias.destroy', ['id'=>$acads->id])); ?>"
                           class="btn-sm btn-danger">Remover</a>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
		<a href="academias/create" class="btn btn-primary">Novo</a>
		<a href="donos" class="btn btn-primary">Donos</a>
		<a href="exercicios" class="btn btn-primary">Exercicios</a>
		<a href="treinos" class="btn btn-primary">Treinos</a>


    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>