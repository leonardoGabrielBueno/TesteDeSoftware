<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Exercicio extends Model
{
    protected $fillable = ['nome', 'descricao', 'tp_exercicio', 'objetivo'];

    public function treinos(){
        return $this->hasMany('App\Treino');
    }

}
