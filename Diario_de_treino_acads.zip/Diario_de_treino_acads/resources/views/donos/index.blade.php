@extends('app')


@section('content')
    <div class="container">
        <h1>Donos</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Nome</th>
                <th>Idade</th>
                <th>Sexo</th>
                <th>Ação</th>
            </tr>
            </thead>

            <tbody>
                @foreach($donos as $don)
                   <tr>
                       <td>{{ $don->nome }}</td>
                       <td>{{ $don->idade }}</td>

                       @if ($don->sexo == 'M')
                           <td>Masculino</td>
                       @elseif ($don->sexo == 'F')
                           <td>Feminino</td>
                       @endif

                       <td>
                           <a href="{{ route('donos.edit', ['id'=>$don->id]) }}"
                                        class="btn-sm btn-success">Editar</a>
                           <a href="{{ route('donos.destroy', ['id'=>$don->id]) }}"
                              class="btn-sm btn-danger">Remover</a>
                       </td>

                   </tr>
                @endforeach
            </tbody>
        </table>
		<a href="donos/create" class="btn btn-primary">Novo</a>
		<a href="academias" class="btn btn-primary">Academias</a>
		<a href="exercicios" class="btn btn-primary">Exercicios</a>
		<a href="treinos" class="btn btn-primary">Treinos</a>
    </div>
@endsection