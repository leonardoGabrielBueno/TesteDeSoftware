<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Treino;
use App\Http\Requests\TreinoRequest;

class TreinoController extends Controller
{
     public function index() {
        $treinos = Treino::all();
        return view('treinos.index', ['treinos'=>$treinos]);
    }

    public function create(){
        return view ('treinos.create');
    }

    public function store (TreinoRequest $request){
        $novo_treino = $request->all();
        Treino::create($novo_treino);

        return redirect()->route('treinos');
    }

    public function destroy ($id) {
        Treino::find($id)->delete();
        return redirect()->route('treinos');
    }

    public function edit ($id) {
        $treino = Treino::find($id);
        return view ('treinos.edit', compact('treino'));
    }

    public function update (TreinoRequest $request, $id) {
        $treino = Treino::find($id)->update($request->all());
        return redirect()->route('treinos');
    }
}
