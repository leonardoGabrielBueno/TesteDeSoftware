<?php

namespace App\Http\Controllers;

use App\Exercicio;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ExercicioRequest;

class ExercicioController extends Controller
{
    public function index() {
        $exercicios = Exercicio::all();
        return view('exercicios.index', ['exercicios'=>$exercicios]);
    }

    public function create(){
        return view ('exercicios.create');
    }

    public function store (ExercicioRequest $request){
        $novo_exercicio = $request->all();
        Exercicio::create($novo_exercicio);

        return redirect()->route('exercicios');
    }

    public function destroy ($id) {
        Exercicio::find($id)->delete();
        return redirect()->route('exercicios');
    }

    public function edit ($id) {
        $exercicio = Exercicio::find($id);
        return view ('exercicios.edit', compact('exercicio'));
    }

    public function update (ExercicioRequest $request, $id) {
        $exercicio = Exercicio::find($id)->update($request->all());
        return redirect()->route('exercicios');
    }
}
