<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Treinos</h1>

        <table class="table table-striped table-bordered table-hover">
            <thead>
            <tr>
                <th>Exercicios</th>
				<th>Musculo ALvo</th>
                <th>repetições</th>
                <th>Series</th>
				<th>Ações</th>
            </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $treinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trein): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
				   <tr>
                       <td><?php echo e($trein->exercicio_id); ?></td>
                       <td><?php echo e($trein->nome); ?></td>
					   <td><?php echo e($trein->repeticoes); ?></td>
					   <td><?php echo e($trein->series); ?></td>

                       <td>
                           <a href="<?php echo e(route('treinos.edit', ['id'=>$trein->id])); ?>"
                                        class="btn-sm btn-success">Editar</a>
                           <a href="<?php echo e(route('treinos.destroy', ['id'=>$trein->id])); ?>"
                              class="btn-sm btn-danger">Remover</a>
                       </td>

                   </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
		<a href="treinos/create" class="btn btn-primary">Novo</a>
		<a href="donos" class="btn btn-primary">Donos</a>
		<a href="exercicios" class="btn btn-primary">Exercicios</a>
		<a href="academias" class="btn btn-primary">Academias</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>