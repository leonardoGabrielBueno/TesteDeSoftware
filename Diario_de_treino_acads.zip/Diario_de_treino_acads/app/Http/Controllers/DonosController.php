<?php

namespace App\Http\Controllers;

use App\Dono;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\DonoRequest;

class DonosController extends Controller
{
    public function index() {
        $donos = Dono::all();
        return view('donos.index', ['donos'=>$donos]);
    }

    public function create(){
        return view ('donos.create');
    }

    public function store (DonoRequest $request){
        $novo_dono = $request->all();
        Dono::create($novo_dono);

        return redirect()->route('donos');
    }

    public function destroy ($id) {
        Dono::find($id)->delete();
        return redirect()->route('donos');
    }

    public function edit ($id) {
        $dono = Dono::find($id);
        return view ('donos.edit', compact('dono'));
    }

    public function update (DonoRequest $request, $id) {
        $dono = Dono::find($id)->update($request->all());
        return redirect()->route('donos');
    }

}
